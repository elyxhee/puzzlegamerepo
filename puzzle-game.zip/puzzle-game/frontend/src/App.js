import React, { useState, useEffect } from 'react';
import Grid from './components/Grid';
import Timer from './components/Timer';
import Leaderboard from './components/Leaderboard';

function App() {
  const [grid, setGrid] = useState([]);
  const [gameOver, setGameOver] = useState(false);
  const [difficulty, setDifficulty] = useState('easy');

  useEffect(() => {
    fetch(`http://localhost:5000/api/generate-puzzle?difficulty=${difficulty}`)
      .then((response) => response.json())
      .then((data) => setGrid(data.puzzle));
  }, [difficulty]);

  // const handleTimeUp = () => {
  //   setGameOver(true);
  // };

  const handleCellClick = (rowIndex, cellIndex) => {
    // Add logic if needed when cell is clicked
  };

  const handleChangeCellValue = (rowIndex, cellIndex, value) => {
    const newGrid = grid.map((row, rIdx) =>
      row.map((cell, cIdx) =>
        rIdx === rowIndex && cIdx === cellIndex ? value : cell
      )
    );
    setGrid(newGrid);
  };

  const saveScore = (score) => {
    fetch('http://localhost:5000/api/save-score', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ userId: 'user1', score }), // Adjust userId as needed
    }).then(() => console.log('Score saved'));
  };
  
  const handleTimeUp = () => {
    setGameOver(true);
    const score = calculateScore(); // Implement your scoring logic here
    saveScore(score);
  };
  const calculateScore = () => {
    // Example scoring logic
    return 1000;
    //return 1000 - (60 - timeLeft); // Adjust based on your timer
  };
  
  

  return (
    <div className="App">
      <h1>Puzzle Game</h1>
      {gameOver ? (
        <>
          <h2>Time's up! Game over!</h2>
          <Leaderboard />
        </>
      ) : (
        <>
          <div>
            <label htmlFor="difficulty">Select Difficulty: </label>
            <select
              id="difficulty"
              value={difficulty}
              onChange={(e) => setDifficulty(e.target.value)}
            >
              <option value="easy">Easy</option>
              <option value="medium">Medium</option>
              <option value="hard">Hard</option>
            </select>
          </div>
          <Timer initialTime={60} onTimeUp={handleTimeUp} />
          <Grid grid={grid} onCellClick={handleCellClick} onChangeCellValue={handleChangeCellValue} />
        </>
      )}
    </div>
  );
}

export default App;
