import React, { useState, useEffect } from 'react';

const Leaderboard = () => {
  const [scores, setScores] = useState([]);

  useEffect(() => {
    fetch('http://localhost:5000/api/scores')
      .then((response) => response.json())
      .then((data) => setScores(data));
  }, []);

  return (
    <div>
      <h2>Leaderboard</h2>
      <ul>
        {scores.map((score, index) => (
          <li key={index}>{score.userId}: {score.score}</li>
        ))}
      </ul>
    </div>
  );
};

export default Leaderboard;
