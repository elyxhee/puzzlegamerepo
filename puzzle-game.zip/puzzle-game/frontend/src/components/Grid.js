import React, { useState } from 'react';
import '../styles/Grid.css';

const Grid = ({ grid, onCellClick, onChangeCellValue }) => {
  const [selectedCell, setSelectedCell] = useState(null);

  const handleCellClick = (rowIndex, cellIndex) => {
    setSelectedCell({ rowIndex, cellIndex });
    onCellClick(rowIndex, cellIndex);
  };

  const handleInputChange = (e) => {
    const value = parseInt(e.target.value, 10);
    if (!isNaN(value)) {
      onChangeCellValue(selectedCell.rowIndex, selectedCell.cellIndex, value);
    }
  };

  return (
    <div className="grid-container">
      {grid.map((row, rowIndex) => (
        <div key={rowIndex} className="grid-row">
          {row.map((cell, cellIndex) => (
            <div
              key={cellIndex}
              className={`grid-cell ${selectedCell?.rowIndex === rowIndex && selectedCell?.cellIndex === cellIndex ? 'selected' : ''}`}
              onClick={() => handleCellClick(rowIndex, cellIndex)}
            >
              {cell !== 0 ? cell : ''}
            </div>
          ))}
        </div>
      ))}
      {selectedCell && (
        <input
          type="number"
          min="1"
          max="9"
          onChange={handleInputChange}
          autoFocus
        />
      )}
    </div>
  );
};

export default Grid;
