const express = require('express');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

// Test route
app.get('/', (req, res) => {
  res.send('Backend is working!');
});
const generatePuzzle = (difficulty = 'easy') => {
    let puzzle;
    switch (difficulty) {
      case 'easy':
        puzzle = [
          [1, 2, 3],
          [4, 5, 6],
          [7, 8, 9],
        ];
        break;
      case 'medium':
        puzzle = [
          [0, 2, 3],
          [4, 0, 6],
          [7, 8, 0],
        ];
        break;
      case 'hard':
        puzzle = [
          [0, 0, 3],
          [4, 0, 0],
          [0, 8, 0],
        ];
        break;
      default:
        puzzle = [
          [1, 2, 3],
          [4, 5, 6],
          [7, 8, 9],
        ];
    }
    return puzzle;
  };
  
  app.get('/api/generate-puzzle', (req, res) => {
    const { difficulty } = req.query;
    const puzzle = generatePuzzle(difficulty);
    res.json({ puzzle });
  });

const scores = [];

app.post('/api/save-score', (req, res) => {
const { userId, score } = req.body;
scores.push({ userId, score });
res.status(201).send();
});

app.get('/api/scores', (req, res) => {
res.json(scores);
});
  
  

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});


